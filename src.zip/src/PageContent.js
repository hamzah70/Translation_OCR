import React from "react"

function PageContent(props){
    console.log(props.converting)
    if(!props.converting){
        return(
            <div>
                <label for="fileInput">Choose File for OCR:</label>
                <input type="file" id="fileInput" name="fileInput" onChange={props.handleChange} />
                <br />
                <br />
                <button type="button" id="Convert" onClick={props.handleClick}>Convert!</button>
                <div id="document-content"></div>
            </div>
        )
    }
    else{
        return(
            <div>
                {console.log("hamzah")}
                {console.log(props.converting)}
                <img src="giphy.gif"></img>
                {console.log("yolo")}
                {/* {props.Tesseract} */}
            </div>
        )
    }
}

export default PageContent