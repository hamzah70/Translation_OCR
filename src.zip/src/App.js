import React from "react"
import "./style.css"
import {Tesseract} from "tesseract.ts";
import PageContent from "./PageContent"
// var Tesseract = window.Tesseract;

class App extends React.Component{
    constructor(){
        super()
        this.state = {
                        image:'',
                        converting:false
                    }
        this.handleClick = this.handleClick.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.Tesseract = this.Tesseract.bind(this)
    }

    Tesseract(){
        const file = this.state.image
        console.log(file)
        Tesseract.recognize(file)
            .progress(function(message){
                console.log(message);
            })
            .then(function(result){
                var contentArea = document.getElementById('document-content');
                console.log(result.text);
            })
            .catch(function(err){
                console.error(err);
            });
        this.setState({
            image:file,
            converting:false
        })
    }

    handleClick(event){
        const file = this.state.image
        console.log(file)
        this.setState({
                image:file,
                converting:true
            })
        // Tesseract.recognize(file)
        //     .progress(function(message){
        //         console.log(message);
        //     })
        //     .then(function(result){
        //         var contentArea = document.getElementById('document-content');
        //         console.log(result.text);
        //     })
        //     .catch(function(err){
        //         console.error(err);
        //     });
        // this.setState({
        //     image:file,
        //     converting:false
        // })
    }
    
    handleChange(event){
        this.setState({
            image :event.target.files[0]
        })
    }

    render(){
        return(
            <div className="ToDoList">
                <PageContent 
                    handleChange={this.handleChange} 
                    handleClick={this.handleClick} 
                    converting ={this.state.converting}
                    Tesseract={this.Tesseract}
                    />
                {/* <label for="fileInput">Choose File for OCR:</label>
                <input type="file" id="fileInput" name="fileInput" onChange={this.handleChange} />
                <br />
                <br />
                <button type="button" id="Convert" onClick={this.handleClick}>Convert!</button>
                <div id="document-content">
                </div> */}
            </div>
        )
    }
}

export default App
